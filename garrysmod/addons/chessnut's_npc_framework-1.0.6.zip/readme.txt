Put the "cn_npc" folder into your server's addons folder.
Go to cn_npc/lua/cn_npcs to add/edit your NPCs.
There is an included sample NPC that shows you examples of adding conversations and networking.


Lua knowledge is required for this add-on as it simply provides a framework, so Lua help
will not be given.