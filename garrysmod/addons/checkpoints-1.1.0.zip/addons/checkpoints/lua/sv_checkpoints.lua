require("races")

util.AddNetworkString("sendRaceCheckpoints")
util.AddNetworkString("openRaceSystem")
util.AddNetworkString("currentCheckpoint")

util.AddNetworkString("createRace")

util.AddNetworkString("checkCheckpoint")

util.AddNetworkString("tptostartpoint")

local raceSystem = races.new()

for k,v in pairs(player.GetAll()) do
	v.CurrentCheckpoint = 1
end
function sendCheckpoints( ply, arg )
	if not arg then
		net.Start("sendRaceCheckpoints")
			net.WriteTable(raceSystem:getRaceCheckpoints())
		net.Send(ply)
	else
		net.Start("sendRaceCheckpoints")
			net.WriteTable(raceSystem:getRaceCheckpoints(arg))
		net.Send(ply)
	end
end


net.Receive("checkCheckpoint",function ( len, ply )
	local checkpoints = raceSystem:getRaceCheckpoints(ply.inRace)

		if tonumber(ply.CurrentCheckpoint) > #checkpoints then
			raceSystem:addWinner(ply.inRace,ply)
			ply.inRace = nil
		else
			for i=1, #checkpoints do
				if ply:GetPos():Distance(checkpoints[ply.CurrentCheckpoint]['pos']) < 150 then
					ply.CurrentCheckpoint = ply.CurrentCheckpoint + 1
					net.Start("currentCheckpoint")
						net.WriteInt(ply.CurrentCheckpoint,32)
					net.Send(ply)
					if tonumber(ply.CurrentCheckpoint) > #checkpoints then
						raceSystem:addWinner(ply.inRace,ply)
						ply.inRace = nil
						ply.CurrentCheckpoint = 1
					end
					return
				end
			end
		end
end)
--REMOVE THIS, ADD TIMER WHEN RACE CREATED INSTEAD
local function spawn( ply )
	ply.CurrentCheckpoint = 1
end
hook.Add( "PlayerInitialSpawn", "raceTimerCreate", spawn )


hook.Add("PlayerSay","openRaceSystem",function ( ply, text, public )
	text = string.lower( text ) -- Make the chat message entirely lowercase
	if ( text == "!race" ) then
		net.Start("openRaceSystem")
		net.Send(ply)
	end
end)


net.Receive("createRace",function( len, ply )
	if not ply:IsAdmin() then return end
	local playersInRace 	= net.ReadTable()
	local checkpoints 		= net.ReadTable()
	local name 				= net.ReadString()
	local startpoint 		= net.ReadVector()

	if #playersInRace==0 then ply:PrintMessage(HUD_PRINTTALK,"No players were selected!") return end
	if #checkpoints==0 then ply:PrintMessage(HUD_PRINTTALK,"No checkpoints were selected!") return end

	raceSystem:addRace(name,playersInRace,checkpoints,startpoint)

	for k,v in pairs(playersInRace) do
		v:SetPos(raceSystem:getRaceStartpoint(#raceSystem:getRaces())+(Vector( math.random( -200, 200 ), math.random( -200, 200 ), 0)))
		v.inRace = #raceSystem:getRaces()
		net.Start("currentCheckpoint")
			net.WriteInt(ply.CurrentCheckpoint,32)
		net.Send(ply)
		
	end
end)

net.Receive("tptostartpoint",function ( len, ply )
	if not ply:IsAdmin() then return end
	ply:SetPos(net.ReadVector())
end)

hook.Add("checkpointsPlayerFinishedRace","playerFinishedRace",function ( raceid, finishposition, winner )
	winner:PrintMessage(HUD_PRINTTALK,"Congratulations, you finished the race in position: "..finishposition.."!")
	if(finishposition==1) then
		if(checkpointsConfig.FinishPos1DarkRPMoneyReward > 0) then
			winner:addMoney(checkpointsConfig.FinishPos1DarkRPMoneyReward)
			winner:PrintMessage(HUD_PRINTTALK,"You have been rewarded with $"..checkpointsConfig.FinishPos1DarkRPMoneyReward.." for coming in 1st")
		end
		if(checkpointsConfig.FinishPos1PSPointsReward > 0) then
			winner:PS_GivePoints(checkpointsConfig.FinishPos1PSPointsReward)
			winner:PrintMessage(HUD_PRINTTALK,"You have been rewarded with "..checkpointsConfig.FinishPos1PSPointsReward.." PS points for coming in 1st")
		end
	elseif (finishposition==2) then
		if(checkpointsConfig.FinishPos2DarkRPMoneyReward > 0) then
			winner:addMoney(checkpointsConfig.FinishPos2DarkRPMoneyReward)
			winner:PrintMessage(HUD_PRINTTALK,"You have been rewarded with $"..checkpointsConfig.FinishPos2DarkRPMoneyReward.." for coming in 2nd")
		end
		if(checkpointsConfig.FinishPos2PSPointsReward > 0) then
			winner:PS_GivePoints(checkpointsConfig.FinishPos2PSPointsReward)
			winner:PrintMessage(HUD_PRINTTALK,"You have been rewarded with "..checkpointsConfig.FinishPos2PSPointsReward.." PS points for coming in 2nd")
		end
	elseif (finishposition==3) then
		if(checkpointsConfig.FinishPos3DarkRPMoneyReward > 0) then
			winner:addMoney(checkpointsConfig.FinishPos3DarkRPMoneyReward)
			winner:PrintMessage(HUD_PRINTTALK,"You have been rewarded with $"..checkpointsConfig.FinishPos3DarkRPMoneyReward.." for coming in 3rd")
		end
		if(checkpointsConfig.FinishPos3PSPointsReward > 0) then
			winner:PS_GivePoints(checkpointsConfig.FinishPos3PSPointsReward)
			winner:PrintMessage(HUD_PRINTTALK,"You have been rewarded with "..checkpointsConfig.FinishPos3PSPointsReward.." PS points for coming in 3rd")
		end
	end
end)