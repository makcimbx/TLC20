checkpointsConfig = {};


checkpointsConfig.Debug = false


checkpointsConfig.FinishPos1DarkRPMoneyReward = 10000
checkpointsConfig.FinishPos1PSPointsReward = 0

checkpointsConfig.FinishPos2DarkRPMoneyReward = 5000
checkpointsConfig.FinishPos2PSPointsReward = 0

checkpointsConfig.FinishPos3DarkRPMoneyReward = 1000
checkpointsConfig.FinishPos3PSPointsReward = 0