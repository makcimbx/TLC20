local raceCheckpoints = {}
local currentCheckpoint = 1
local raceFinished = false
local lastCheck = 0

local z = 0
local up = true
local smooth = 0

--derma vars
local selectedPlayers = {}
local selectedCheckpoints = {}
local selectedStartpoint = {}
--
net.Receive("sendRaceCheckpoints",function (  )
	raceCheckpoints = net.ReadTable()
	if(#raceCheckpoints > 0) then
		for i=1, #raceCheckpoints do
			for b=1, #raceCheckpoints[i] do
			end
		end
	end
end)
hook.Add("Tick","checkCheckpointPos",function (  )
	if(#raceCheckpoints > 0) then
		if not raceFinished then
			if LocalPlayer():GetPos():Distance(raceCheckpoints[currentCheckpoint]['pos']) < 100 then
				if lastCheck < CurTime() then
					net.Start("checkCheckpoint")
					net.SendToServer()
					lastCheck = CurTime() + 0.5
				end
			end
		end
	end
end)

hook.Add("PostDrawOpaqueRenderables","drawCheckpoints",function (  )

	if up then
		smooth = math.Approach(smooth, 20, 10*FrameTime())
	else
		smooth = math.Approach(smooth, -20, 10*FrameTime())
	end
	if smooth >= 20 then
		up = false
	elseif smooth <= 0 then
		up = true
	end

	local ang = LocalPlayer():EyeAngles()
	 
	 
	ang:RotateAroundAxis( ang:Forward(), 90 )
	ang:RotateAroundAxis( ang:Right(), 90 )

	local a = Angle(0,0,0)
	a:RotateAroundAxis(Vector(1,0,0),90)
	a.y = LocalPlayer():GetAngles().y - 90

	
	--print("Checkpoints: "..#raceCheckpoints)
	--print(aceFinished)
	if(#raceCheckpoints > 0) then
		if raceFinished==false then
		--for i=1, #raceCheckpoints do
			cam.Start3D2D(raceCheckpoints[currentCheckpoint]['pos'],Angle(0,0,0),1)
				drawCheckpoint()
			cam.End3D2D()

			cam.Start3D2D(Vector(raceCheckpoints[currentCheckpoint]['pos'].x, raceCheckpoints[currentCheckpoint]['pos'].y,raceCheckpoints[currentCheckpoint]['pos'].z+smooth),Angle(0,ang.y,90),1)
				drawCheckpointArrow()
			cam.End3D2D()
		--end
		end
	end

	if(#selectedCheckpoints > 0) then

		for i=1, #selectedCheckpoints do
			cam.Start3D2D(selectedCheckpoints[i],Angle(0,0,0),1)
				drawCheckpoint()
			cam.End3D2D()
			cam.Start3D2D(Vector(selectedCheckpoints[i].x, selectedCheckpoints[i].y,selectedCheckpoints[i].z+smooth),Angle(0,ang.y,90),1)
				drawCheckpointArrow()
			cam.End3D2D()
		end
	end
	
end)

net.Receive("currentCheckpoint",function (  )
	
	currentCheckpoint = net.ReadInt(32)
	if currentCheckpoint > #raceCheckpoints then
		raceFinished = true
	else
		raceFinished = false 
	end

end)
function Ply(name)
	name = string.lower(name);
	for _,v in ipairs(player.GetHumans()) do
		if(string.find(string.lower(v:Name()),name,1,true) != nil)
			then return v;
		end
	end
end

function openGui(  )
	if not LocalPlayer():IsAdmin() then print("Not admin") return end
	local Frame = vgui.Create( "DFrame" )
	
	Frame:SetSize( 500, 500 )
	Frame:SetPos( ScrW()/2-Frame:GetWide()/2, ScrH()/2-Frame:GetTall()/2 )
	Frame:SetTitle( "Race configurator" )
	Frame:SetVisible( true )
	Frame:SetDraggable( false )
	Frame:ShowCloseButton( true )
	function Frame:Paint( w, h )
		draw.RoundedBox( 0, 0, 0, 500, 25, Color( 0, 0, 0,200 ) )
		draw.RoundedBox( 8, 0, 0, w, h, Color( 0, 0, 0,180 ) )
		draw.SimpleText("Players to add to race: ","Trebuchet24",125,25,Color(0,255,0,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_TOP)
		draw.SimpleText("Checkpoints in race: ","Trebuchet24",125,250,Color(0,255,0,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_TOP)
	end
	

	local PlayerList = vgui.Create("DListView",Frame)
	PlayerList:SetPos(2,50)
	PlayerList:SetSize(250,250-50-2)
	PlayerList:SetMultiSelect(true)
	PlayerList:AddColumn("Name")
	
	function PlayerList:Paint( w, h )
		draw.RoundedBox( 8, 0, 0, w, h, Color( 255, 255, 255,255 ) )
	end
	for k,v in pairs(player.GetAll()) do
		PlayerList:AddLine(v:Nick()) -- Add lines
	end

	local Positions = vgui.Create("DListView",Frame)
	Positions:SetPos(2,275)
	Positions:SetSize(250,250-50-2)
	Positions:SetMultiSelect(true)
	Positions:AddColumn("Position")
	function Positions:Paint( w, h )
		draw.RoundedBox( 8, 0, 0, w, h, Color( 255, 255, 255,255 ) )
	end
	if #selectedCheckpoints > 0 then
		for i=1, #selectedCheckpoints do
			Positions:AddLine(selectedCheckpoints[i])
		end
	end
	local DermaButton = vgui.Create( "DButton", Frame ) // Create the button and parent it to the frame
	DermaButton:SetText( "Add checkpoint" )					// Set the text on the button
	DermaButton:SetPos( 2, 500-25 )					// Set the position on the frame
	DermaButton:SetSize( 123, 23 )					// Set the size
	DermaButton.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
		table.insert(selectedCheckpoints,LocalPlayer():GetPos())
		Positions:AddLine(LocalPlayer():GetPos())
	end
	function DermaButton:Paint( w, h )
		draw.RoundedBox( 8, 0, 0, w, h, Color( 150, 255, 150,255 ) )
	end
	local ButtonRemoveCheckpoints = vgui.Create( "DButton", Frame ) // Create the button and parent it to the frame
	ButtonRemoveCheckpoints:SetText( "Remove checkpoints" )					// Set the text on the button
	ButtonRemoveCheckpoints:SetPos( 125, 500-25 )					// Set the position on the frame
	ButtonRemoveCheckpoints:SetSize( 123, 23 )					// Set the size
	ButtonRemoveCheckpoints.DoClick = function()				// A custom function run when clicked ( note the . instead of : )
		table.Empty(selectedCheckpoints)
		Positions:Clear()
	end
	function ButtonRemoveCheckpoints:Paint( w, h )
		draw.RoundedBox( 8, 0, 0, w, h, Color( 255, 150, 150,255 ) )
	end

	local ButtonStartRace = vgui.Create( "DButton", Frame )
	ButtonStartRace:SetText( "Start Race" )
	ButtonStartRace:SetPos( 300, 500-25 )
	ButtonStartRace:SetSize( 150-5, 23 )
	ButtonStartRace.DoClick = function()				

	local lines = PlayerList:GetSelected()

	for _, line in pairs( lines ) do
	    table.insert(selectedPlayers,Ply(line:GetColumnText(1)))
	end
	
		if #selectedPlayers==0 then LocalPlayer():PrintMessage(HUD_PRINTTALK,"No players were selected!") return end
		if #selectedStartpoint==0 then LocalPlayer():PrintMessage(HUD_PRINTTALK,"No startpoint was selected!") return end
		if #selectedCheckpoints==0 then LocalPlayer():PrintMessage(HUD_PRINTTALK,"No checkpoints were selected!") return end

		net.Start("createRace")
			net.WriteTable(selectedPlayers)
			net.WriteTable(selectedCheckpoints)
			net.WriteString("Race #1")
			net.WriteVector(selectedStartpoint[1])
		net.SendToServer()
		Frame:Close()
		selectedCheckpoints = {}
		selectedPlayers = {}
	end
	function ButtonStartRace:Paint( w, h )
		draw.RoundedBox( 8, 0, 0, w, h, Color( 150, 255, 150,255 ) )
	end


	local StartPoint = vgui.Create("DListView",Frame)
	StartPoint:SetPos(254,50)
	StartPoint:SetSize(250-8,35)
	StartPoint:SetMultiSelect(false)
	StartPoint:AddColumn("Pos")
	StartPoint.OnRowRightClick = function (  )
	local lines = StartPoint:GetSelected()
		for _, line in pairs( lines ) do

		    net.Start("tptostartpoint")
		    	net.WriteVector(line:GetColumnText(1))
		    net.SendToServer()
		end
	end
	if #selectedStartpoint > 0 then
		for i=1, #selectedStartpoint do
			StartPoint:AddLine(selectedStartpoint[i])
		end
	end

	function StartPoint:Paint( w, h )
		draw.RoundedBox( 8, 0, 0, w, h, Color( 255, 255, 255,255 ) )
	end

	local ButtonStartpoint = vgui.Create( "DButton", Frame )
	ButtonStartpoint:SetText( "Set StartPoint" )
	ButtonStartpoint:SetPos( 300, 87 )
	ButtonStartpoint:SetSize( 150-5, 23 )
	ButtonStartpoint.DoClick = function()
		StartPoint:Clear()
		table.Empty(selectedStartpoint)
		StartPoint:AddLine(LocalPlayer():GetPos())
		table.insert(selectedStartpoint,LocalPlayer():GetPos())		
	end

	function ButtonStartpoint:Paint( w, h )
		draw.RoundedBox( 8, 0, 0, w, h, Color( 150, 255, 150,255 ) )

	end



	Frame:MakePopup()

end
net.Receive("openRaceSystem",function (  )
	openGui()
end)
local triangle = {
	{ x = 0, y = -10 },
	{ x = -20, y = -70 },
	{ x = 20, y = -70 },


}
function drawCheckpoint(  )
	surface.SetDrawColor(255,0,0,255)
	surface.DrawCircle( 0, 0, 20,Color(255,255,255,255))

end
function drawCheckpointArrow(  )
	surface.SetDrawColor(255,0,0,255)
	surface.DrawPoly( triangle )
end