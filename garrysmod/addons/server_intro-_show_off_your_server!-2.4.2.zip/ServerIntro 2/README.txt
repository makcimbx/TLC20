First of all, thanks for buying this (unless you leaked it, you cunt).

To change settings and music go to serverintro/lua/autorun/client/serverintro.lua. The options are explained.

Here's a guide on adding a new location.
Step 1: Go to the place you want to start and look in the direction you want the user to look at first.
Step 2: Type glide_pos1 in console
Step 2a: Go to the ending positon and type glide_pos2
Step 3: You should get an output like this:
{ startpos = Vector( 245.59164428711, -2719.4440917969, 1776.1875 ), endpos = Vector( 791.25817871094, 5783.2426757813, 315.19720458984 ), ang = Angle( 11.439979553223, 85.710083007813, 0 ), ang2 = Angle( 8.4699783325195, 87.690093994141, 0 ), speed = 0.1 },
Step 3a: Add a new entry to that table named text, like so, and change to how you want:
{ startpos = Vector( 245.59164428711, -2719.4440917969, 1776.1875 ), endpos = Vector( 791.25817871094, 5783.2426757813, 315.19720458984 ), ang = Angle( 11.439979553223, 85.710083007813, 0 ), ang2 = Angle( 8.4699783325195, 87.690093994141, 0 ), speed = 0.1, text = "hello" },
Step 4: Add a new line to the locations table in sh_serverintro.lua, remembering a comma after the previous line, then paste the output from that command 

If you want to make your text look fancy, check out markup.txt

If you have any issues with anything I will be happy to help. DO NOT ADD ME ON STEAM!!!
Submit a ticket on scriptfodder. I will check these a lot more than steam requests. Please take in to mind that I am not always around 24/7 so it may take a while to get round to answering you.