surface.CreateFont( "titleFont", {
	font = "Roboto Th",
	size = 56,
	weight = 400,
	antialias = true
} )

surface.CreateFont( "questionFont", {
	font = "Roboto Th",
	size = 34,
	weight = 400,
	antialias = true
} )

surface.CreateFont( "chooseFont", {
	font = "Roboto Lt",
	size = 24,
	weight = 400,
	antialias = true
} )
surface.CreateFont( "buttonsFont", {
	font = "Roboto Lt",
	size = 22,
	weight = 400,
	antialias = true
} )

net.Receive("firsttimert", function()

	local mainFrame = vgui.Create("DAlert")
	mainFrame:SetTitle(rtLang.welcomeTitle)
	mainFrame:SetText(rtLang.welcomeText)

end)

net.Receive("questions", function()

	local mainFrame = vgui.Create("DFrame")
	mainFrame:SetSize( ScrW(),  ScrH() * 0.6 )
	mainFrame:SetBackgroundBlur( true )
	mainFrame:SetDraggable( false )
	mainFrame:ShowCloseButton( false )
	mainFrame:SetTitle("")
	mainFrame:Center()
	mainFrame:MakePopup()
	mainFrame.Init = function()
		mainFrame.startTime = SysTime()
	end
	mainFrame.Paint = function()
		Derma_DrawBackgroundBlur(mainFrame, mainFrame.startTime)
		draw.RoundedBox( 0, 0, 0, mainFrame:GetWide(), mainFrame:GetTall(), Color( 41, 128, 185))
	end

	local contentHolder = vgui.Create("DPanel", mainFrame)
	contentHolder:SetSize( mainFrame:GetWide() * 0.7,  mainFrame:GetTall() * 0.9 )
	contentHolder:Center()
	contentHolder.Paint = function() end

	local titleLabel = vgui.Create("DLabel", contentHolder)
	titleLabel:SetText(rtLang.questionsTitle)
	titleLabel:SetFont("titleFont")
	titleLabel:SizeToContents()
	titleLabel:SetPos(0, 0)
	titleLabel:SetColor(Color(255, 255, 255))

	local questionsHolder = vgui.Create( "DPanelList", contentHolder)
	questionsHolder:SetSize( contentHolder:GetWide() - 5, contentHolder:GetTall() - 170 )
	questionsHolder:SetPos( 0, 100 )
	questionsHolder:SetSpacing( 10 )
	questionsHolder:EnableHorizontal( false )
	questionsHolder:EnableVerticalScrollbar( true )

	local question = {}
	local choose = {}
	local questionBlock = {}
	local rightAnswers = {}

	for k,v in pairs(net.ReadTable()) do
		local id = k
		questionBlock[id] = vgui.Create( "DPanel" )
		questionBlock[id]:SetTall( 90 )
		questionBlock[id].Paint = function() end

		question[id] = vgui.Create( "DLabel", questionBlock[id])
	    question[id]:SetText(v["question"])
	    question[id]:SetFont("questionFont")
	    question[id]:SizeToContents()
	    question[id]:SetColor(Color(255, 255, 255))
	    question[id]:SetPos(0,0)

	    choose[id] = vgui.Create("DComboBox", questionBlock[id])
	    choose[id]:SetSize( questionsHolder:GetWide() - 20 , 40 )
		choose[id]:SetFont("chooseFont")
		choose[id]:SetValue( rtLang.defualtOption )
		choose[id]:SetPos(0, question[id]:GetTall())
		choose[id].Paint = function()
			draw.RoundedBox( 0, 0, 0, choose[id]:GetWide(), choose[id]:GetTall(), Color( 255,255,255, 255) )
		end

		local answers = util.JSONToTable(v["answers"])
		for k,v in pairs( answers ) do
			choose[id]:AddChoice( v, k )
		end

		questionsHolder:AddItem( questionBlock[id] )

		rightAnswers[id] = tonumber(v["rightanswer"])
	end

	local sendButton = vgui.Create("DButton", contentHolder)
	sendButton:SetText("Send")
	sendButton:SetSize(140, 40)
	sendButton:SetColor(Color(255,255,255))
	sendButton:SetFont("buttonsFont")
	sendButton:SetPos( contentHolder:GetWide() - (sendButton:GetWide() + 5), contentHolder:GetTall() - (sendButton:GetTall() + 5) )
	sendButton.Paint = function()
		draw.RoundedBox( 0, 0, 0, sendButton:GetWide(), sendButton:GetTall(), Color( 46, 204, 113 ) )
	end
	sendButton.DoClick = function()
		local answers = {}
		local allgood
		for k,v in pairs(choose) do
			if choose[k]:GetSelectedID() then 
				table.insert(answers, choose[k]:GetOptionData(choose[k]:GetSelectedID()))
				allgood = true
			else
				Derma_Query(rtLang.forgotAnswer, "Error", "Ok")
				allgood = false
				break
			end
		end
		if allgood then
			net.Start("checkanswers")
				net.WriteTable(answers)
				mainFrame:Close()
			net.SendToServer()
		end
	end

	local cancelButton = vgui.Create("DButton", contentHolder)
	cancelButton:SetText("Cancel")
	cancelButton:SetSize(140, 40)
	cancelButton:SetPos( contentHolder:GetWide() - (cancelButton:GetWide() + 150), contentHolder:GetTall() - (cancelButton:GetTall() + 5) )
	cancelButton:SetColor(Color(255,255,255))
	cancelButton:SetFont("buttonsFont")
	cancelButton.Paint = function()
		draw.RoundedBox( 0, 0, 0, cancelButton:GetWide(), cancelButton:GetTall(), Color( 231, 76, 60))
	end
	cancelButton.DoClick = function()
		RunConsoleCommand("rt_cancel")
	end	
end)

net.Receive("rtresults", function()

	local mainFrame = vgui.Create("DAlert")
	if net.ReadBool() then
		mainFrame:SetTitle(rtLang.passedTitle)
		mainFrame:SetText(rtLang.passedText)
		mainFrame:Passed()
	else
		mainFrame:SetTitle(string.format( rtLang.failedTitle, net.ReadString() ))
		mainFrame:SetText(rtLang.failedText)
	end

end)
	
--[[Admin shit]]--

net.Receive("addquestions", function()

	local mainFrame = vgui.Create( "DFrame" )
	mainFrame:SetSize( 500, 500 )
	mainFrame:SetTitle( "" )
	mainFrame:SetVisible( true )
	mainFrame:SetDraggable( false )
	mainFrame:ShowCloseButton( false )
	mainFrame:Center()
	mainFrame:MakePopup()
	mainFrame.Init = function()
		mainFrame.startTime = SysTime()
	end
	mainFrame.Paint = function()
		Derma_DrawBackgroundBlur(mainFrame, mainFrame.startTime)
		draw.RoundedBox( 0, 0, 0, mainFrame:GetWide(), mainFrame:GetTall(), Color(226,226,226) )
		draw.RoundedBox( 0, 0, 0, mainFrame:GetWide(), 30, Color( 52, 73, 94 ) )
	end
	
	local closeButton = vgui.Create("DButton", mainFrame)
	closeButton:SetSize( 70, 30 )
	closeButton:SetPos( 430 , 0 )
	closeButton:SetColor( Color( 255, 255, 255 ))
	closeButton:SetText("X")
	closeButton:SetVisible( true )

	closeButton.Paint = function( )
		if closeButton.isHover then
			draw.RoundedBox( 0, 0, 0, closeButton:GetWide(), closeButton:GetTall(), Color( 192, 57, 43 ) )
		else
			draw.RoundedBox( 0, 0, 0, closeButton:GetWide(), closeButton:GetTall(), Color( 231, 76, 60 ) )
		end
	end

	closeButton.OnCursorEntered = function()
		closeButton.isHover = true
	end

	closeButton.OnCursorExited = function()
		closeButton.isHover = false
	end

	closeButton.DoClick = function()
		mainFrame:Close()
	end

	local titleLabel = vgui.Create("DLabel", mainFrame)
	titleLabel:SetText( "New question" )
	titleLabel:SetFont("questionFont")
	titleLabel:SetColor( Color( 255, 255, 255 ) )
	titleLabel:SizeToContents()
	titleLabel:SetPos( 6, -2 )


	local contentHolder = vgui.Create("DPanel", mainFrame)
	contentHolder:SetSize( 480, 430 )
	contentHolder:SetPos( 10, 40 )

	local explainLabel = vgui.Create("DLabel", contentHolder)
	explainLabel:SetFont("buttonsFont")
	explainLabel:SetPos( 10, 10 )
	explainLabel:SetColor( Color( 52, 73, 94 ) )
	explainLabel:SetAutoStretchVertical( true )
	explainLabel:SetWide( 430 )
	explainLabel:SetWrap( true )
	explainLabel:SetText("Here you need to write your question and the answers then select the correct answer.")

	local questionEntry = vgui.Create("DTextEntry", contentHolder)
	questionEntry:SetPos( 10, 115 )
	questionEntry:SetSize( 460, 30 )
	questionEntry:SetFont("buttonsFont")
	questionEntry:SetText("Write here the question!")

	answerEntry = {}
	answerCheckbox = {}

	answerEntry[1] = vgui.Create("DTextEntry", contentHolder)
	answerEntry[1]:SetPos( 50, 150 )
	answerEntry[1]:SetSize( 420, 30 )
	answerEntry[1]:SetFont("buttonsFont")
	answerEntry[1]:SetText("Write here the first answer!")

	local answerCheckbox1 = vgui.Create( "DChoice", contentHolder)
	answerCheckbox1:SetPos( 20, 158 )
	answerCheckbox1:SetValue( 1 )

	answerEntry[2] = vgui.Create("DTextEntry", contentHolder)
	answerEntry[2]:SetPos( 50, 185 )
	answerEntry[2]:SetSize( 420, 30 )
	answerEntry[2]:SetFont("buttonsFont")
	answerEntry[2]:SetText("Write here the second answer!")

	local answerCheckbox2 = vgui.Create( "DChoice", contentHolder)
	answerCheckbox2:SetPos( 20, 193 )
	answerCheckbox2:SetValue( 2 )

	answerEntry[3] = vgui.Create("DTextEntry", contentHolder)
	answerEntry[3]:SetPos( 50, 220 )
	answerEntry[3]:SetSize( 420, 30 )
	answerEntry[3]:SetFont("buttonsFont")
	answerEntry[3]:SetText("Write here the third answer!")

	local answerCheckbox3 = vgui.Create( "DChoice", contentHolder)
	answerCheckbox3:SetPos( 20, 228 )
	answerCheckbox3:SetValue( 3 )

	answerEntry[4] = vgui.Create("DTextEntry", contentHolder)
	answerEntry[4]:SetPos( 50, 255 )
	answerEntry[4]:SetSize( 420, 30 )
	answerEntry[4]:SetFont("buttonsFont")
	answerEntry[4]:SetText("Write here the fourth answer!")

	local answerCheckbox4 = vgui.Create( "DChoice", contentHolder)
	answerCheckbox4:SetPos( 20, 263 )
	answerCheckbox4:SetValue( 4 )

	local group = {answerCheckbox1, answerCheckbox2, answerCheckbox3, answerCheckbox4}
	answerCheckbox1:SetGroup(group)
	answerCheckbox2:SetGroup(group)
	answerCheckbox3:SetGroup(group)
	answerCheckbox4:SetGroup(group)

	local addButton = vgui.Create("DButton", contentHolder)
	addButton:SetSize( 180, 40 )
	addButton:SetPos( 275, 370 )
	addButton:SetColor( Color( 255, 255, 255) )
	addButton:SetFont("buttonsFont")
	addButton:SetText("Add question")
	addButton.DoClick = function()
		local rightanswer
		for i, button in ipairs(group) do
			if button:GetSelected() then
				rightanswer = button:GetValue()
			end
		end
		net.Start("addquestion")
			local answers = { string.Replace(answerEntry[1]:GetValue(), "'", ""), string.Replace(answerEntry[2]:GetValue(), "'", ""), string.Replace(answerEntry[3]:GetValue(), "'", ""), string.Replace(answerEntry[4]:GetValue(), "'", "") }
			PrintTable({questionEntry:GetValue(), util.TableToJSON(answers), rightanswer})
			net.WriteTable({questionEntry:GetValue(), util.TableToJSON(answers), rightanswer})
		net.SendToServer()
		mainFrame:Close()
	end
	addButton.Paint = function()
		draw.RoundedBox( 0, 0, 0, addButton:GetWide(), addButton:GetTall(), Color( 41, 128, 185 ) )
	end

end)

net.Receive("adminselectquestion", function()

	local mainFrame = vgui.Create( "DFrame" )
	mainFrame:SetSize( 500, 500 )
	mainFrame:SetTitle( "" )
	mainFrame:SetVisible( true )
	mainFrame:SetDraggable( false )
	mainFrame:ShowCloseButton( false )
	mainFrame:Center()
	mainFrame:MakePopup()
	mainFrame.Init = function()
		mainFrame.startTime = SysTime()
	end
	mainFrame.Paint = function()
		Derma_DrawBackgroundBlur(mainFrame, mainFrame.startTime)
		draw.RoundedBox( 0, 0, 0, mainFrame:GetWide(), mainFrame:GetTall(), Color(226,226,226) )
		draw.RoundedBox( 0, 0, 0, mainFrame:GetWide(), 30, Color( 52, 73, 94 ) )
	end
	
	local closeButton = vgui.Create("DButton", mainFrame)
	closeButton:SetSize( 70, 30 )
	closeButton:SetPos( 430 , 0 )
	closeButton:SetColor( Color( 255, 255, 255 ))
	closeButton:SetText("X")
	closeButton:SetVisible( true )

	closeButton.Paint = function( )
		if closeButton.isHover then
			draw.RoundedBox( 0, 0, 0, closeButton:GetWide(), closeButton:GetTall(), Color( 192, 57, 43 ) )
		else
			draw.RoundedBox( 0, 0, 0, closeButton:GetWide(), closeButton:GetTall(), Color( 231, 76, 60 ) )
		end
	end

	closeButton.OnCursorEntered = function()
		closeButton.isHover = true
	end

	closeButton.OnCursorExited = function()
		closeButton.isHover = false
	end

	closeButton.DoClick = function()
		mainFrame:Close()
	end

	local title = vgui.Create("DLabel", mainFrame)
	title:SetText( "Select question to edit." )
	title:SetFont("titlefont")
	title:SetColor( Color( 255, 255, 255 ) )
	title:SizeToContents()
	title:SetPos( 6, 2 )

	local questlist = vgui.Create( "DListView", mainFrame )
	questlist:SetSize( 480, 430 )
	questlist:SetPos( 10, 40 )
	questlist:SetMultiSelect( false )
	questlist:AddColumn( "ID" )
	questlist:AddColumn( "Question" )
	
	for k,v in pairs(net.ReadTable()) do
		questlist:AddLine( v.id, v.question )
	end

	questlist.OnRowRightClick = function ( btn, line )
	    local questsOptions = DermaMenu()
		questsOptions:AddOption("Delete Question", function() 
			Derma_Query("Are you sure that you want to delete this question?", "Warning!",
				"Yes", function() RunConsoleCommand("question_delete", questlist:GetLine(line):GetValue(1)) questlist:RemoveLine(line) end,
				"No")
		end )
		questsOptions:AddOption("Edit Question", function() 
			RunConsoleCommand("question_request", questlist:GetLine(line):GetValue(1))
		end )
	    questsOptions:Open()
	end

	questlist.DoDoubleClick = function( id, line )
		RunConsoleCommand("question_request", questlist:GetLine(line):GetValue(1))
	end

end )

net.Receive("editquestionmenu", function()
	
	local data = net.ReadTable()

	local mainFrame = vgui.Create( "DFrame" )
	mainFrame:SetSize( 500, 500 )
	mainFrame:SetTitle( "" )
	mainFrame:SetVisible( true )
	mainFrame:SetDraggable( false )
	mainFrame:ShowCloseButton( false )
	mainFrame:Center()
	mainFrame:MakePopup()
	mainFrame.Init = function()
		mainFrame.startTime = SysTime()
	end
	mainFrame.Paint = function()
		Derma_DrawBackgroundBlur(mainFrame, mainFrame.startTime)
		draw.RoundedBox( 0, 0, 0, mainFrame:GetWide(), mainFrame:GetTall(), Color(226,226,226) )
		draw.RoundedBox( 0, 0, 0, mainFrame:GetWide(), 30, Color( 52, 73, 94 ) )
	end
	
	local closeButton = vgui.Create("DButton", mainFrame)
	closeButton:SetSize( 70, 30 )
	closeButton:SetPos( 430 , 0 )
	closeButton:SetColor( Color( 255, 255, 255 ))
	closeButton:SetText("X")
	closeButton:SetVisible( true )

	closeButton.Paint = function( )
		if closeButton.isHover then
			draw.RoundedBox( 0, 0, 0, closeButton:GetWide(), closeButton:GetTall(), Color( 192, 57, 43 ) )
		else
			draw.RoundedBox( 0, 0, 0, closeButton:GetWide(), closeButton:GetTall(), Color( 231, 76, 60 ) )
		end
	end

	closeButton.OnCursorEntered = function()
		closeButton.isHover = true
	end

	closeButton.OnCursorExited = function()
		closeButton.isHover = false
	end

	closeButton.DoClick = function()
		mainFrame:Close()
	end

	local titleLabel = vgui.Create("DLabel", mainFrame)
	titleLabel:SetText( "New question" )
	titleLabel:SetFont("questionFont")
	titleLabel:SetColor( Color( 255, 255, 255 ) )
	titleLabel:SizeToContents()
	titleLabel:SetPos( 6, -2 )


	local contentHolder = vgui.Create("DPanel", mainFrame)
	contentHolder:SetSize( 480, 430 )
	contentHolder:SetPos( 10, 40 )

	local explainLabel = vgui.Create("DLabel", contentHolder)
	explainLabel:SetFont("buttonsFont")
	explainLabel:SetPos( 10, 10 )
	explainLabel:SetColor( Color( 52, 73, 94 ) )
	explainLabel:SetAutoStretchVertical( true )
	explainLabel:SetWide( 430 )
	explainLabel:SetWrap( true )
	explainLabel:SetText("Here you need to write your question and the answers then select the correct answer.")

	local questionEntry = vgui.Create("DTextEntry", contentHolder)
	questionEntry:SetPos( 10, 115 )
	questionEntry:SetSize( 460, 30 )
	questionEntry:SetFont("buttonsFont")
	questionEntry:SetText(data[1]["question"])

	answerEntry = {}
	answerCheckbox = {}

	answerEntry[1] = vgui.Create("DTextEntry", contentHolder)
	answerEntry[1]:SetPos( 50, 150 )
	answerEntry[1]:SetSize( 420, 30 )
	answerEntry[1]:SetFont("buttonsFont")
	

	local answerCheckbox1 = vgui.Create( "DChoice", contentHolder)
	answerCheckbox1:SetPos( 20, 158 )
	answerCheckbox1:SetValue( 1 )

	answerEntry[2] = vgui.Create("DTextEntry", contentHolder)
	answerEntry[2]:SetPos( 50, 185 )
	answerEntry[2]:SetSize( 420, 30 )
	answerEntry[2]:SetFont("buttonsFont")
	

	local answerCheckbox2 = vgui.Create( "DChoice", contentHolder)
	answerCheckbox2:SetPos( 20, 193 )
	answerCheckbox2:SetValue( 2 )

	answerEntry[3] = vgui.Create("DTextEntry", contentHolder)
	answerEntry[3]:SetPos( 50, 220 )
	answerEntry[3]:SetSize( 420, 30 )
	answerEntry[3]:SetFont("buttonsFont")
	

	local answerCheckbox3 = vgui.Create( "DChoice", contentHolder)
	answerCheckbox3:SetPos( 20, 228 )
	answerCheckbox3:SetValue( 3 )

	answerEntry[4] = vgui.Create("DTextEntry", contentHolder)
	answerEntry[4]:SetPos( 50, 255 )
	answerEntry[4]:SetSize( 420, 30 )
	answerEntry[4]:SetFont("buttonsFont")
	

	local answerCheckbox4 = vgui.Create( "DChoice", contentHolder)
	answerCheckbox4:SetPos( 20, 263 )
	answerCheckbox4:SetValue( 4 )


	local group = {answerCheckbox1, answerCheckbox2, answerCheckbox3, answerCheckbox4}
	answerCheckbox1:SetGroup(group)
	answerCheckbox2:SetGroup(group)
	answerCheckbox3:SetGroup(group)
	answerCheckbox4:SetGroup(group)

	local addButton = vgui.Create("DButton", contentHolder)
	addButton:SetSize( 180, 40 )
	addButton:SetPos( 275, 370 )
	addButton:SetColor( Color( 255, 255, 255) )
	addButton:SetFont("buttonsFont")
	addButton:SetText("Edit qusetion")
	addButton.DoClick = function()
		local rightanswer
		for i, button in ipairs(group) do
			if button:GetSelected() then
				rightanswer = button:GetValue()
			end
		end
		net.Start("editquestion")
			local answers = { string.Replace(answerEntry[1]:GetValue(), "'", ""), string.Replace(answerEntry[2]:GetValue(), "'", ""), string.Replace(answerEntry[3]:GetValue(), "'", ""), string.Replace(answerEntry[4]:GetValue(), "'", "") }
			net.WriteTable({questionEntry:GetValue(), util.TableToJSON(answers), rightanswer, data[1]["id"]})
		net.SendToServer()
		mainFrame:Close()
	end
	addButton.Paint = function()
		draw.RoundedBox( 0, 0, 0, addButton:GetWide(), addButton:GetTall(), Color( 41, 128, 185 ) )
	end
	local answers = util.JSONToTable(data[1]["answers"])
	for k,v in pairs(answers) do
		answerEntry[k]:SetText(answers[k])
	end
	for i, button in ipairs(group) do
		if i == tonumber(data[1]["rightanswer"]) then
			button:SetSelected( true )
		end
	end

end)