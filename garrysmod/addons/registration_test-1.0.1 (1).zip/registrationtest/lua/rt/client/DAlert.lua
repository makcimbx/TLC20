local PANEL = {}
 
function PANEL:Init()

	self.mainFrame = vgui.Create("DFrame")
	self.mainFrame:SetSize( ScrW(),  ScrH() * 0.32 )
	self.mainFrame:SetBackgroundBlur( true )
	self.mainFrame:SetDraggable( false )
	self.mainFrame:ShowCloseButton( false )
	self.mainFrame:SetTitle("")
	self.mainFrame:Center()
	self.mainFrame:MakePopup()
	self.mainFrame.Init = function()
		self.mainFrame.startTime = SysTime()
	end
	self.mainFrame.Paint = function()
		Derma_DrawBackgroundBlur(self.mainFrame, self.mainFrame.startTime)
		draw.RoundedBox( 0, 0, 0, self.mainFrame:GetWide(), self.mainFrame:GetTall(), Color( 41, 128, 185))
	end

	local contentHolder = vgui.Create("DPanel", self.mainFrame)
	contentHolder:SetSize( self.mainFrame:GetWide() * 0.7,  self.mainFrame:GetTall() * 0.9 )
	contentHolder:Center()
	contentHolder.Paint = function() end

	self.titleLabel = vgui.Create("DLabel", contentHolder)
	self.titleLabel:SetFont("titleFont")
	self.titleLabel:SetPos(0, 0)
	self.titleLabel:SetColor(Color(255, 255, 255))

	self.textLabel = vgui.Create("DLabel", contentHolder)
	self.textLabel:SetPos(0, 100)
	self.textLabel:SetAutoStretchVertical( true )
	self.textLabel:SetWide( contentHolder:GetWide() - 5 )
	self.textLabel:SetWrap( true )
	self.textLabel:SetFont("chooseFont")

	self.sendbutton = vgui.Create("DButton", contentHolder)
	self.sendbutton:SetText("Ok")
	self.sendbutton:SetSize(140, 40)
	self.sendbutton:SetColor(Color(255,255,255))
	self.sendbutton:SetFont("buttonsFont")
	self.sendbutton:SetPos( contentHolder:GetWide() - (self.sendbutton:GetWide() + 5), contentHolder:GetTall() - (self.sendbutton:GetTall() + 5) )
	self.sendbutton.Paint = function()
		draw.RoundedBox( 0, 0, 0, self.sendbutton:GetWide(), self.sendbutton:GetTall(), Color( 46, 204, 113 ) )
	end
	self.sendbutton.DoClick = function()
		RunConsoleCommand("rt_questions")
		self.mainFrame:Close()
	end

	self.cancelbutton = vgui.Create("DButton", contentHolder)
	self.cancelbutton:SetText("No, Thanks.")
	self.cancelbutton:SetSize(140, 40)
	self.cancelbutton:SetPos( contentHolder:GetWide() - (self.cancelbutton:GetWide() + 150), contentHolder:GetTall() - (self.cancelbutton:GetTall() + 5) )
	self.cancelbutton:SetColor(Color(255,255,255))
	self.cancelbutton:SetFont("buttonsFont")
	self.cancelbutton.Paint = function()
		draw.RoundedBox( 0, 0, 0, self.cancelbutton:GetWide(), self.cancelbutton:GetTall(), Color( 231, 76, 60))
	end
	self.cancelbutton.DoClick = function()
		RunConsoleCommand("rt_cancel")
	end

end

function PANEL:SetTitle( title )

	self.titleLabel:SetText( title )
	self.titleLabel:SizeToContents()

end
function PANEL:SetText( text )

	self.textLabel:SetText( text )

end
function PANEL:Passed()
	self.sendbutton.DoClick = function()
		self.mainFrame:Close()
	end
	self.cancelbutton:SetVisible(false)
end
derma.DefineControl("DAlert", "Custom Panel", PANEL)