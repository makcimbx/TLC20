rtConfig = {}


rtConfig.Attempts = 4

-- Ban the player if hes failing in the test or just kick him? (ban is true kick is false)
rtConfig.banPlayer = false

-- If you choose you to ban the player for who much time (in minutes)
rtConfig.banTime = 120


rtLang = {}

rtLang.welcomeTitle = "Not so fast!"
rtLang.welcomeText = "Hey buddy, not so fast. Before you going to play in our server you need to answer some questions. If you don't want just click on 'No, Thanks' and you will be kicked. If you think that you can, just click on 'Ok'"

rtLang.questionsTitle = "You need to answer some questions!"
rtLang.defualtOption = "Select the right answer!"
rtLang.forgotAnswer = "You forgot to answer on some questions!"

rtLang.passedTitle = "Welcome."
rtLang.passedText = "You passed the test, click 'Ok' to start to play in our server."

rtLang.failedTitle = "ERROR - You failed in the Registration test. %s attepms left."
rtLang.failedText = "Click on Ok to do the Registration test again or on Cancel to get out from the server."

rtLang.cancelKick = "You chose to not answer the questions. If you want to get into our server you need to answer the questions."
rtLang.noAttemptsKick = "No attempts left."